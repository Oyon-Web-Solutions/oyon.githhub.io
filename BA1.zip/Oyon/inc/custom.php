<?php
/* 
This file is included into functions.php
Use this file to add custom PHP code to functions.php 
*/

?>